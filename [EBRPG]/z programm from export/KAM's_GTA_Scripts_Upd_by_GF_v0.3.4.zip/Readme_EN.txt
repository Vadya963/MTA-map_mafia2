Updated and improved version of KAM's skipts.
Based on the original Kam's scripts.
This script was tested in 3ds max 2009 and 2012 and 2017.

Complete with the script there is a fixed and updated GTA Material


Download the latest version of the script
https://yadi.sk/d/DQMt4tMM3TTV5e
or
https://drive.google.com/drive/folders/1hjKlZzNjxilEBfDGrSIN2iJF-1xSwVxU?usp=sharing


Changes and updates:

--------- [ DFF IO ] ---------------


What was added:
  (28.10.2019)
  - choice of material before you import the DFF (GTAMat or standard)
  
  (17.03.2018)
 - mass import and export DFF's
 - import / export Night prelite
 - import / export Vertex Alpha
 - import / export UV2 channel
 - import / export 2dfx (only light sources)
 - optional interface for configuring 2dfx
 - additional locking dff (new)


  (23.03.2018)
 - import / export Bump maps
 - import / export Dual maps
 - import / export Normal Map and Reflection (Adaptation for Normal map Plugin from DK)
 - auto-save the interface settings DFF IO after each change


What's been fixed:

  (28.10.2019)
 - import 2dfx (fixed a critical bug)
 - import map IO texture extension 
 - UPDATED map IO script and improved its compatibility with the latest version of the DFF importer
 - updated script interface
 - other minor code fixes and improvements

   (01.09.2019)
 - MAP IO
 
   (17.03.2018)
 - exporting a hierarchy of models
 - export of normals
 - import of color from light sources 2dfx

   (23.03.2018)
 - export models of characters
 - importing a model hierarchy
 - general script code repair


Additionally:
 - added more warnings and tips when exporting
 - added export log ( F11 listener)
 - updated and improved script interface
 - added optional UV2 coordinate compression
 - added additional tools to work with the model
 - added progress-bar and fixed script freezes
 - added default settings for exporting prelite
 - added menu GTA tools scripts in the top menu bar 3ds max


Additional utilities:

 - Prelit Tools
         the script for mass configuration prelite

 - Fix models pivot
         script for mass alignment of the pivot position of the model to integer coordinates before exporting the mapping

 - Align pivot to center
         script for mass equalization of pivot in the center

 - Col Export (mass)
         script for mass export of col (cst)


[COL IO]  - not changed
[IFP IO]  - not changed
[Map IO] - small fix


Authors

============

- 19.12.05 -
Kam, Odie, Pioneer

Official post on the forum: http://gtaforums.com/topic/218318-rel-kams-maxscript-going-over-quick-update/



-17.03.2018 -

Goldfish - Goldfish-1994@yandex.ru

Updating the script: 28.10.2019 (v 0.3.2)

For questions and suggestions, write here (support): https://vk.com/topic-99725313_37821803


