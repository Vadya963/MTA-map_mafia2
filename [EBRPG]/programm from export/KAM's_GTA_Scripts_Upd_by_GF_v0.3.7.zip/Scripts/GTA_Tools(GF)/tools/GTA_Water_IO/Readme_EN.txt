

	GTA Water IO 1.0b
======================================

upd: 20.03.2019

Compatible: 3ds max 2009 and up (maybe versions and less)

Autor: Goldfish 
Official script support: https://vk.com/topic-99725313_35674835
Permalink to download / update the script: https://yadi.sk/d/NsuFPYkGNsuixA


		*****
Script for export and import of water for gta sa
has an interface for setting water parameters

features:
- support for triangular water exports
- water import along with all its parameters
- auxiliary utilities for working and setting up water

in the archive there is an image with a detailed description of the script interface


Installation:
Place the GTAWaterIO.ms script in any folder, for example ../3dmax_folder/Scripts/
Run from the menu of the program 3dmax or by dragging to the window 3dmax


Enjoy using it!