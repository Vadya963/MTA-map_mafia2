Vertex Color Smooth Tool v 1.0
 
Last update: 20.05.20
 
Script features (video): https://youtu.be/fYnOswq3jyI

Download / update script: https://yadi.sk/d/DBhhLxCsW1L6CQ

Installation: not required
just drag the script file into the 3ds max window or open via the Max Script -> Run script...

Author: 
Goldfish


Support: 
Goldfish-1994@yandex.ru 
https://vk.com/topic-99725313_35674835